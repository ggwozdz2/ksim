# mypy: disable-error-code="override"
"""Defines simple task for training a standing policy for the default humanoid using an GRU actor."""

from dataclasses import dataclass
from typing import Generic, TypeVar
import xax
import ksim

from examples.walking import HumanoidWalkingTask, HumanoidWalkingTaskConfig

# Etc. - chyba sami musimy zadbać o dostęp do wszystkich importów. W szczególności prawie na pewno trzeba dodać jax etc.

@dataclass
class HumanoidStandingTaskConfig(HumanoidWalkingTaskConfig):
    max_steps: int = xax.field(
        value=1000,
        help="The maximum number of steps to train for.",
    )

Config = TypeVar("Config", bound=HumanoidStandingTaskConfig)

###

###

class HumanoidStandingTask(HumanoidWalkingTask[Config], Generic[Config]):
    def get_rewards(self, physics_model: ksim.PhysicsModel) -> list[ksim.Reward]:
        return [
            ksim.BaseHeightRangeReward(z_lower=1.1, z_upper=1.5, dropoff=10.0, scale=1.0),
            ksim.StayAliveReward(scale=1.0),
        ]


    def is_training_over(self, state: ksim.State) -> bool:
        return state.num_steps >= self.config.max_steps

