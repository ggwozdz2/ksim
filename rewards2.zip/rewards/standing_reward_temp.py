# mypy: disable-error-code="override"
"""Defines simple task for training a standing policy for the default humanoid using an GRU actor."""

from dataclasses import dataclass
from typing import Generic, TypeVar
import xax
import ksim

from examples.walking import HumanoidWalkingTask, HumanoidWalkingTaskConfig

# Etc. - chyba sami musimy zadbać o dostęp do wszystkich importów. W szczególności prawie na pewno trzeba dodać jax etc.

@dataclass
class HumanoidStandingTaskConfig(HumanoidWalkingTaskConfig):
    max_steps: int = xax.field(
        value=1000,
        help="The maximum number of steps to train for.",
    )

Config = TypeVar("Config", bound=HumanoidStandingTaskConfig)

###
# TODO - define the reward functions here: #
###

class HumanoidStandingTask(HumanoidWalkingTask[Config], Generic[Config]):
    def get_rewards(self, physics_model: ksim.PhysicsModel) -> list[ksim.Reward]:
        return [
            # TODO - update the reward functions here - add rewards.
        ]


    def is_training_over(self, state: ksim.State) -> bool:
        return state.num_steps >= self.config.max_steps

