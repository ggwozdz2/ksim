import ksim
# Etc. - chyba sami musimy zadbać o dostęp do wszystkich importów. W szczególności prawie na pewno trzeba dodać jax etc.

def get_rewards(self, physics_model: ksim.PhysicsModel) -> list[ksim.Reward]:
        # TODO - update the reward functions here:
        return [
            ksim.BaseHeightRangeReward(z_lower=1.1, z_upper=1.5, dropoff=10.0, scale=1.0),
            ksim.StayAliveReward(scale=1.0),
        ]