import ksim
# Etc. - chyba sami musimy zadbać o dostęp do wszystkich importów. W szczególności prawie na pewno trzeba dodać jax etc.

###
# TODO - define the reward functions here:
#
#
###